﻿
namespace Minor.Dag39.GamesBackend.DAL
{
    public class Program
    {
        public static void Main(string[] Args)
        {
            // Empty program for entity framework
        }
    }
}
