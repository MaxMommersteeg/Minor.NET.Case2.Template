﻿using Minor.WSA.Commons;

namespace $safeprojectname$.Events {
    public class RoomCreatedEvent : DomainEvent
    {

    }
}
